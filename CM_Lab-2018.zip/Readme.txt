My readme file for CM Lab, CPE 333. 
We will have 3 C programs, 1 Word Doc, and this Readme text file. 